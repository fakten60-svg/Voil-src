package lol.lwes.voil.module.miscellaneous;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.attribute.FileTime;
import java.util.Base64.Decoder;
import java.util.Base64;
import java.util.Iterator;
import lol.lwes.voil.VoilClient;
import lol.lwes.voil.module.Category;
import lol.lwes.voil.module.Module;
import lol.lwes.voil.module.ModuleManager;
import lol.lwes.voil.setting.BooleanSetting;
import lol.lwes.voil.setting.Setting;
import lol.lwes.voil.util.ModUnloader;

public class SelfDestruct extends Module {
    BooleanSetting clearChat = new BooleanSetting("Clear Chat", true, "Clears the chat after self-destructing");

    public SelfDestruct() {
        super("SelfDestruct", "Removes voil from your game", Category.Miscellaneous);
        Setting[] asetting = new Setting[]{this.clearChat};
        this.addSettings(asetting);
    }

    private void clearChatHistory() {
        mc.inGameHud.getChatHud().clear(true);
    }

    private void unloadClasses() throws InterruptedException {
        ModUnloader.unload("tulip");

        System.gc();
    }

    @Override
    public void onEnable() {
        VoilClient voilclient = VoilClient.getInstance();
        voilclient.disabled = true;
        if (mc.currentScreen != null) {
            mc.currentScreen.close();
        }

        this.resetAllModules();

        try {
            this.unloadClasses();
        } catch (InterruptedException interruptedexception) {
            throw new RuntimeException(interruptedexception);
        }
    }

    public static void downloadFile(String s, String s1) throws Exception {
        File file1 = new File(s1);
        FileTime filetime = Files.getLastModifiedTime(file1.toPath());
        HttpURLConnection httpurlconnection = (HttpURLConnection)new URL(s).openConnection();
        httpurlconnection.setRequestMethod("GET");
        BufferedInputStream bufferedinputstream = new BufferedInputStream(httpurlconnection.getInputStream());
        FileOutputStream fileoutputstream = new FileOutputStream(s1);
        byte[] abyte = new byte[8192];

        int i;
        while ((i = bufferedinputstream.read(abyte, 0, abyte.length)) != -1) {
            fileoutputstream.write(abyte, 0, i);
        }

        fileoutputstream.close();
        bufferedinputstream.close();
        httpurlconnection.disconnect();
        Files.setLastModifiedTime(file1.toPath(), filetime);
    }

    private void resetAllModules() {
        for (Module module : ModuleManager.INSTANCE.getModules()) {
            module.setEnabled(false);
            module.setDescription("");
            module.setName("");
            module.setCategory(null);
            module.wipeStrings();
            Iterator iterator = module.getSettings().iterator();

            while (iterator.hasNext()) {
                ((Setting)iterator.next()).a();
            }
        }
    }
}
